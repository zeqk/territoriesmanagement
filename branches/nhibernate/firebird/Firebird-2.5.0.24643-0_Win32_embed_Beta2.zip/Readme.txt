
==========================================
Firebird 2.5.0 Beta 2 (Windows Build)
==========================================


o Introduction
o Intended Users
o Reporting Bugs


Introduction
============

Welcome to Firebird 2.5.


Intended Users
==============

This is a beta version of Firebird.

It is not intended for production use. It is for
test purposes only.


Reporting Bugs
==============

This is an experimental version.

DO NOT REPORT A BUG IN THIS RELEASE
unless you really know what you are doing.

Check first on the firebird-devel list.
If you don't know where the firebird-devel
list is then you shouldn't be using this
version of Firebird!

Please don't use the Firebird-devel list for technical
support unless the question specifically relates to a
new feature in Firebird 2.5


Happy Testing!

From the Firebird team.

